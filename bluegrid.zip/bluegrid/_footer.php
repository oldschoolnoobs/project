			</div>
			<div style='clear: both'></div>
		</div>
		<div class='push'></div>
	</div>
	<div class='footerDiv'>
		<?php $btThemeObj->displayCopyright(); ?>
	</div>
	
	<?php include(BASE_DIRECTORY."themes/include_footer.php"); ?>
</body>
</html>